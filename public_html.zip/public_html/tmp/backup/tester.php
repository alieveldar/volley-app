<?php
class Tester {
	function say_hello(){
		phpinfo();
	}
}
?>