<?php
 $dbhost = 'lvh.me';
 $dbname = 'eDb';
 $dbuser = 'volleyadmin';
 $dbpassword = 'volley2018';
 $title = 'Школа волейбола';
 $description = 'Это дескрипция';
?>